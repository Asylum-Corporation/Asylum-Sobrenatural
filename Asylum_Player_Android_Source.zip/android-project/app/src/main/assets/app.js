(() => {
  'use strict';

  const STORAGE_KEY = 'asylum_player_characters_v1';
  const ACTIVE_KEY = 'asylum_player_active_character';

  const ATTRS = [
    { key: 'corpo', label: 'Corpo' },
    { key: 'agilidade', label: 'Agilidade' },
    { key: 'intelecto', label: 'Intelecto' },
    { key: 'presenca', label: 'Presença' },
    { key: 'espirito', label: 'Espírito' }
  ];

  const ARCHETYPES = {
    investigador: { corpo: 30, agilidade: 35, intelecto: 60, presenca: 40, espirito: 35 },
    combatente: { corpo: 55, agilidade: 55, intelecto: 30, presenca: 30, espirito: 30 },
    ritualista: { corpo: 30, agilidade: 30, intelecto: 40, presenca: 40, espirito: 60 },
    sobrevivente: { corpo: 50, agilidade: 45, intelecto: 35, presenca: 35, espirito: 35 },
    medico: { corpo: 35, agilidade: 35, intelecto: 55, presenca: 40, espirito: 35 },
    personalizado: { corpo: 40, agilidade: 40, intelecto: 40, presenca: 40, espirito: 40 }
  };

  const FREE_ITEMS = [
    { name: 'Faca', qty: 1, note: 'Equipamento inicial' },
    { name: 'Celular', qty: 1, note: 'Equipamento inicial' },
    { name: 'Documentos', qty: 1, note: 'Equipamento inicial' },
    { name: 'Roupas', qty: 1, note: 'Equipamento inicial' },
    { name: 'Mochila', qty: 1, note: 'Equipamento inicial' }
  ];

  const KITS = [
    { id: 'nenhum', name: 'Sem kit', price: 0, items: [], description: 'Começa apenas com os equipamentos gratuitos.' },
    { id: 'investigador', name: 'Kit Investigador', price: 300, items: [
      ['Lanterna', 1], ['Lupa', 1], ['Câmera Fotográfica', 1], ['Gravador de Fita', 1], ['Kit de Coleta de Evidências', 1]
    ]},
    { id: 'medico', name: 'Kit Médico', price: 140, items: [
      ['Kit de Primeiros Socorros', 1], ['Analgésicos', 1], ['Lanterna', 1]
    ]},
    { id: 'sobrevivente', name: 'Kit Sobrevivente', price: 100, items: [
      ['Cantil', 1], ['Corda (10m)', 1], ['Canivete', 1], ['Isqueiro', 1]
    ]},
    { id: 'ritualista', name: 'Kit Ritualista', price: 100, items: [
      ['Sal Grosso (Pacote)', 1], ['Velas (Conjunto)', 1], ['Água Benta', 1], ['Crucifixo', 1]
    ]},
    { id: 'combatente', name: 'Kit Combatente', price: 350, items: [
      ['Revólver .38', 1], ['Munição .38', 12], ['Pé de Cabra', 1], ['Lanterna', 1]
    ]}
  ];

  const SHOP = [
    ['Armas Brancas','Faca',0,'Dano 5','Corpo'],['Armas Brancas','Bastão',40,'Dano 7','Corpo'],['Armas Brancas','Punhal',50,'Dano 6','Corpo'],['Armas Brancas','Faca de Caça',80,'Dano 7','Corpo'],['Armas Brancas','Chicote',90,'Dano 6','Corpo'],['Armas Brancas','Machado',150,'Dano 10','Corpo'],
    ['Improvisadas','Garrafa Quebrada',10,'Dano 4','Corpo'],['Improvisadas','Pé de Cabra',60,'Dano 8','Corpo'],['Improvisadas','Taco de Beisebol',70,'Dano 8','Corpo'],
    ['Armas Curtas','Revólver .38',250,'Dano 9','Agilidade • .38'],['Armas Curtas','Pistola 9mm',300,'Dano 10','Agilidade • 9mm'],['Armas Curtas','Shotgun de Cano Curto',450,'Dano 14','Agilidade • Calibre 12'],
    ['Armas Longas','Espingarda de Caça',500,'Dano 16','Agilidade • Calibre 12'],['Armas Longas','Carabina',600,'Dano 15','Agilidade • 5.56'],['Armas Longas','Rifle de Caça',700,'Dano 18','Agilidade • 7.62'],['Armas Longas','Rifle de Precisão',1200,'Dano 25','Agilidade • 7.62'],['Armas Longas','Metralhadora',2000,'Dano 16','Agilidade • 5.56'],
    ['Armas Especiais','Estilingue',20,'Dano 4','Agilidade • Esferas'],['Armas Especiais','Arco Longo',300,'Dano 10','Agilidade • Flechas'],['Armas Especiais','Balestra',400,'Dano 12','Agilidade • Virotes'],
    ['Munições','Munição .38 (12)',40,'12 unidades','Revólver .38'],['Munições','Munição 9mm (15)',50,'15 unidades','Pistola 9mm'],['Munições','Cartuchos Calibre 12 (10)',80,'10 unidades','Shotgun e Espingarda'],['Munições','Munição 5.56 (20)',120,'20 unidades','Carabina e Metralhadora'],['Munições','Munição 7.62 (20)',150,'20 unidades','Rifles'],['Munições','Flechas (5)',50,'5 unidades','Arco Longo'],['Munições','Virotes de Balestra (5)',60,'5 unidades','Balestra'],['Munições','Esferas para Estilingue (20)',10,'20 unidades','Estilingue'],
    ['Investigação','Lanterna',30,'Item',''],['Investigação','Lupa',20,'Item',''],['Investigação','Câmera Fotográfica',120,'Item',''],['Investigação','Gravador de Fita',80,'Item',''],['Investigação','Kit de Coleta de Evidências',90,'Item',''],
    ['Medicina','Analgésicos',25,'Item',''],['Medicina','Kit de Primeiros Socorros',100,'Item',''],
    ['Comunicação','Celular',0,'Grátis','Equipamento inicial'],['Comunicação','Rádio Comunicador',150,'Item',''],
    ['Proteção','Colete Balístico',400,'Item',''],
    ['Sobrevivência','Cantil',25,'Item',''],['Sobrevivência','Isqueiro',15,'Item',''],['Sobrevivência','Corda (10m)',40,'Item',''],['Sobrevivência','Canivete',35,'Item',''],
    ['Ritualísticos','Sal Grosso (Pacote)',10,'Item',''],['Ritualísticos','Água Benta',30,'Item',''],['Ritualísticos','Crucifixo',50,'Item',''],['Ritualísticos','Velas (Conjunto)',20,'Item',''],
    ['Ferramentas','Kit de Arrombamento',60,'Item',''],['Ferramentas','Kit de Sinais (Giz)',15,'Item','']
  ].map((x, i) => ({ id: `shop-${i}`, category: x[0], name: x[1], price: x[2], detail: x[3], extra: x[4] }));

  const RITUALS = {
    1: ['Sentir Presença', 'Revelar Vestígio', 'Voz Tranquila'],
    2: ['Círculo de Proteção', 'Purificação', 'Sussurro Distante'],
    3: ['Selo de Contenção', 'Comunicação com os Mortos', 'Vínculo Revelado'],
    4: ['Quebra de Maldição', 'Exorcismo', 'Escudo Espiritual'],
    5: ['Banimento', 'Chama Consagrada', 'Porta Selada']
  };

  let characters = loadCharacters();
  let activeId = localStorage.getItem(ACTIVE_KEY) || '';
  let selectedKitId = 'investigador';
  let currentAttributes = { ...ARCHETYPES.investigador };
  let deferredInstallPrompt = null;

  const $ = (id) => document.getElementById(id);

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    renderAttributeControls();
    renderKitCards();
    renderCharacterList();
    renderShopCategories();
    renderShop();
    renderRules();
    renderRituals();
    bindEvents();
    updateCreatorPreview();
    registerServiceWorker();
  }

  function bindEvents() {
    document.querySelectorAll('.bottom-nav button').forEach(btn => {
      btn.addEventListener('click', () => showView(btn.dataset.view));
    });

    $('newCharacterBtn').addEventListener('click', () => openCreator());
    $('emptyCreateBtn').addEventListener('click', () => openCreator());
    $('cancelCreateBtn').addEventListener('click', () => showView('home'));
    $('characterForm').addEventListener('submit', saveCharacterFromForm);
    $('archetypeSelect').addEventListener('change', e => {
      const key = e.target.value;
      currentAttributes = { ...ARCHETYPES[key] };
      syncAttributeInputs();
      updateCreatorPreview();
    });

    ['charName','playerName','charAge','charProfession','personalItem','charStory'].forEach(id => {
      $(id).addEventListener('input', updateCreatorPreview);
    });

    $('editCharacterBtn').addEventListener('click', () => {
      const c = getActiveCharacter();
      if (c) openCreator(c);
    });

    $('deleteCharacterBtn').addEventListener('click', () => {
      const c = getActiveCharacter();
      if (!c) return;
      confirmAction('Excluir ficha', `A ficha de ${c.name} será removida deste aparelho.`, () => {
        characters = characters.filter(x => x.id !== c.id);
        persistCharacters();
        localStorage.removeItem(ACTIVE_KEY);
        activeId = '';
        renderCharacterList();
        showView('home');
        toast('Ficha excluída.');
      });
    });

    $('shopSearch').addEventListener('input', renderShop);
    $('shopCategory').addEventListener('change', renderShop);
    $('exportBtn').addEventListener('click', exportBackup);
    $('importInput').addEventListener('change', importBackup);

    window.addEventListener('beforeinstallprompt', e => {
      e.preventDefault();
      deferredInstallPrompt = e;
      $('installBtn').classList.remove('hidden');
    });

    $('installBtn').addEventListener('click', async () => {
      if (!deferredInstallPrompt) return;
      deferredInstallPrompt.prompt();
      await deferredInstallPrompt.userChoice;
      deferredInstallPrompt = null;
      $('installBtn').classList.add('hidden');
    });
  }

  function showView(name) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const target = $(`view-${name}`);
    if (target) target.classList.add('active');
    document.querySelectorAll('.bottom-nav button').forEach(b => b.classList.toggle('active', b.dataset.view === name));
    if (name === 'home') renderCharacterList();
    if (name === 'shop') renderShop();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function renderAttributeControls() {
    $('attributesGrid').innerHTML = ATTRS.map(attr => `
      <div class="attribute-control" data-attr="${attr.key}">
        <div class="label"><span>${attr.label}</span><span id="label-${attr.key}">40%</span></div>
        <div class="stepper">
          <button type="button" data-step="-5" aria-label="Diminuir ${attr.label}">−</button>
          <input id="attr-${attr.key}" type="number" min="20" max="60" step="5" value="40" inputmode="numeric" />
          <button type="button" data-step="5" aria-label="Aumentar ${attr.label}">+</button>
        </div>
      </div>
    `).join('');

    document.querySelectorAll('.attribute-control').forEach(box => {
      const key = box.dataset.attr;
      const input = $(`attr-${key}`);
      box.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', () => {
          const value = clamp(Number(input.value || 20) + Number(btn.dataset.step), 20, 60);
          input.value = value;
          onAttributeInput(key, value);
        });
      });
      input.addEventListener('input', () => onAttributeInput(key, clamp(roundTo5(Number(input.value || 20)), 20, 60)));
      input.addEventListener('blur', () => {
        input.value = currentAttributes[key];
      });
    });
    syncAttributeInputs();
  }

  function onAttributeInput(key, value) {
    currentAttributes[key] = value;
    $(`attr-${key}`).value = value;
    $('archetypeSelect').value = 'personalizado';
    updateAttributeSummary();
    updateCreatorPreview();
  }

  function syncAttributeInputs() {
    ATTRS.forEach(attr => {
      const value = currentAttributes[attr.key];
      $(`attr-${attr.key}`).value = value;
      $(`label-${attr.key}`).textContent = `${value}%`;
    });
    updateAttributeSummary();
  }

  function updateAttributeSummary() {
    const total = Object.values(currentAttributes).reduce((a, b) => a + Number(b), 0);
    const remaining = 200 - total;
    $('attributeTotal').textContent = `${total}%`;
    $('attributeRemaining').textContent = `${remaining}%`;
    $('attributeRemaining').style.color = remaining === 0 ? 'var(--green)' : 'var(--red-bright)';
    ATTRS.forEach(attr => {
      $(`label-${attr.key}`).textContent = `${currentAttributes[attr.key]}%`;
    });
    const valid = total === 200 && Object.values(currentAttributes).every(v => v >= 20 && v <= 60);
    $('attributeError').classList.toggle('hidden', valid);
    return valid;
  }

  function renderKitCards() {
    $('kitCards').innerHTML = KITS.map(kit => `
      <label class="kit-card ${kit.id === selectedKitId ? 'selected' : ''}" data-kit="${kit.id}">
        <input type="radio" name="kit" value="${kit.id}" ${kit.id === selectedKitId ? 'checked' : ''}/>
        <h5>${kit.name}</h5>
        <div class="price">${kit.price === 0 ? 'Grátis' : `${kit.price} Créditos`}</div>
        ${kit.description ? `<p class="muted">${kit.description}</p>` : ''}
        ${kit.items.length ? `<ul>${kit.items.map(i => `<li>${i[1]}× ${i[0]}</li>`).join('')}</ul>` : ''}
      </label>
    `).join('');

    document.querySelectorAll('.kit-card').forEach(card => {
      card.addEventListener('click', () => {
        selectedKitId = card.dataset.kit;
        document.querySelectorAll('.kit-card').forEach(c => c.classList.toggle('selected', c.dataset.kit === selectedKitId));
        document.querySelectorAll('input[name="kit"]').forEach(i => i.checked = i.value === selectedKitId);
        updateCreatorPreview();
      });
    });
  }

  function updateCreatorPreview() {
    const life = calcLife(currentAttributes.corpo);
    const energy = calcEnergy(currentAttributes.espirito);
    const kit = KITS.find(k => k.id === selectedKitId) || KITS[0];
    $('previewLife').textContent = life;
    $('previewEnergy').textContent = energy;
    $('previewCredits').textContent = formatCredits(1000 - kit.price);
    $('previewKit').textContent = kit.name;
  }

  function openCreator(character = null) {
    $('characterForm').reset();
    if (character) {
      $('creatorTitle').textContent = `Editar ${character.name}`;
      $('editingId').value = character.id;
      $('charName').value = character.name || '';
      $('playerName').value = character.player || '';
      $('charAge').value = character.age || 25;
      $('charProfession').value = character.profession || '';
      $('personalItem').value = character.personalItem || '';
      $('charStory').value = character.story || '';
      currentAttributes = { ...character.attributes };
      $('archetypeSelect').value = 'personalizado';
      selectedKitId = character.initialKit || 'nenhum';
    } else {
      $('creatorTitle').textContent = 'Nova ficha';
      $('editingId').value = '';
      $('charAge').value = 25;
      currentAttributes = { ...ARCHETYPES.investigador };
      $('archetypeSelect').value = 'investigador';
      selectedKitId = 'investigador';
    }
    syncAttributeInputs();
    renderKitCards();
    updateCreatorPreview();
    showView('create');
  }

  function saveCharacterFromForm(event) {
    event.preventDefault();
    if (!updateAttributeSummary()) {
      toast('Revise a distribuição dos atributos.');
      return;
    }

    const editingId = $('editingId').value;
    const existing = characters.find(c => c.id === editingId);
    const kit = KITS.find(k => k.id === selectedKitId) || KITS[0];
    const inventory = existing ? normalizeInventory(existing.inventory) : buildInitialInventory(kit);
    const maxLife = calcLife(currentAttributes.corpo);
    const maxEnergy = calcEnergy(currentAttributes.espirito);

    const character = {
      id: editingId || cryptoRandomId(),
      name: $('charName').value.trim(),
      player: $('playerName').value.trim(),
      age: Number($('charAge').value || 25),
      profession: $('charProfession').value.trim(),
      personalItem: $('personalItem').value.trim(),
      story: $('charStory').value.trim(),
      level: existing?.level || 1,
      attributes: { ...currentAttributes },
      maxLife,
      currentLife: existing ? clamp(existing.currentLife, 0, maxLife) : maxLife,
      maxEnergy,
      currentEnergy: existing ? clamp(existing.currentEnergy, 0, maxEnergy) : maxEnergy,
      credits: existing ? existing.credits : 1000 - kit.price,
      initialKit: existing ? existing.initialKit : kit.id,
      inventory,
      notes: existing?.notes || '',
      createdAt: existing?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (!character.name) {
      toast('Informe o nome do personagem.');
      return;
    }

    if (existing) {
      characters = characters.map(c => c.id === character.id ? character : c);
    } else {
      characters.push(character);
    }
    activeId = character.id;
    localStorage.setItem(ACTIVE_KEY, activeId);
    persistCharacters();
    renderCharacterList();
    renderSheet(character);
    showView('sheet');
    toast('Ficha salva neste aparelho.');
  }

  function buildInitialInventory(kit) {
    const items = FREE_ITEMS.map(x => ({ ...x }));
    if (document.getElementById('personalItem')?.value.trim()) {
      items.push({ name: document.getElementById('personalItem').value.trim(), qty: 1, note: 'Objeto pessoal' });
    }
    kit.items.forEach(([name, qty]) => addInventoryItem(items, name, qty, 'Kit inicial'));
    return normalizeInventory(items);
  }

  function renderCharacterList() {
    const list = $('characterList');
    const empty = $('emptyState');
    list.innerHTML = '';
    empty.classList.toggle('hidden', characters.length > 0);
    list.classList.toggle('hidden', characters.length === 0);

    characters
      .slice()
      .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
      .forEach(c => {
        const card = document.createElement('article');
        card.className = 'character-card';
        card.innerHTML = `
          <span class="eyebrow">Nível ${c.level || 1}</span>
          <h4>${escapeHtml(c.name)}</h4>
          <p>${escapeHtml(c.profession || 'Caçador')}</p>
          <div class="card-stats">
            <div><span>Vida</span><strong>${c.currentLife}/${c.maxLife}</strong></div>
            <div><span>Energia</span><strong>${c.currentEnergy}/${c.maxEnergy}</strong></div>
            <div><span>Créditos</span><strong>${formatCredits(c.credits)}</strong></div>
          </div>`;
        card.addEventListener('click', () => {
          activeId = c.id;
          localStorage.setItem(ACTIVE_KEY, activeId);
          renderSheet(c);
          showView('sheet');
        });
        list.appendChild(card);
      });
  }

  function renderSheet(character = getActiveCharacter()) {
    if (!character) {
      showView('home');
      return;
    }
    $('sheetName').textContent = character.name;
    const kit = KITS.find(k => k.id === character.initialKit)?.name || 'Sem kit';

    $('sheetContent').innerHTML = `
      <div class="sheet-identity">
        <article class="panel identity-card">
          <span class="eyebrow">Nível ${character.level || 1}</span>
          <h2>${escapeHtml(character.name)}</h2>
          <p>${escapeHtml(character.profession || 'Caçador')}</p>
          <div class="bio-list">
            <div><span>Jogador</span><strong>${escapeHtml(character.player || '—')}</strong></div>
            <div><span>Idade</span><strong>${character.age || '—'}</strong></div>
            <div><span>Kit inicial</span><strong>${escapeHtml(kit)}</strong></div>
            <div><span>Objeto pessoal</span><strong>${escapeHtml(character.personalItem || '—')}</strong></div>
          </div>
        </article>
        <article class="panel">
          ${renderMeter('Vida', character.currentLife, character.maxLife, 'life')}
          <div style="height:14px"></div>
          ${renderMeter('Energia', character.currentEnergy, character.maxEnergy, 'energy')}
          <div style="height:14px"></div>
          <div class="stat-card credits"><span>Créditos</span><strong id="sheetCredits">${formatCredits(character.credits)}</strong></div>
          <div class="inventory-add" style="margin-top:10px">
            <input id="creditsDelta" type="number" min="1" value="10" inputmode="numeric" aria-label="Quantidade de créditos" />
            <button class="ghost-btn" id="removeCreditsBtn" type="button">− Créditos</button>
            <button class="primary-btn" id="addCreditsBtn" type="button">+ Créditos</button>
          </div>
        </article>
      </div>

      <article class="panel">
        <h4>Atributos</h4>
        <div class="attribute-display">
          ${ATTRS.map(a => `<div><span>${a.label}</span><strong>${character.attributes[a.key]}%</strong></div>`).join('')}
        </div>
      </article>

      <article class="panel">
        <h4>História</h4>
        <p class="muted">${escapeHtml(character.story || 'Nenhuma história registrada.').replace(/\n/g, '<br>')}</p>
      </article>

      <article class="panel">
        <div class="section-head" style="margin:0 0 10px">
          <div><h4 style="margin:0">Inventário</h4><p class="muted">Use os botões para ajustar quantidades.</p></div>
        </div>
        <div id="inventoryList" class="inventory-list"></div>
        <div class="inventory-add">
          <input id="customItemName" placeholder="Adicionar item" />
          <input id="customItemQty" type="number" min="1" value="1" inputmode="numeric" aria-label="Quantidade" />
          <button id="customItemAddBtn" class="primary-btn" type="button">Adicionar</button>
        </div>
      </article>

      <article class="panel">
        <h4>Anotações do jogador</h4>
        <textarea id="playerNotes" rows="6" placeholder="Pistas, contatos, nomes, dívidas, suspeitas...">${escapeHtml(character.notes || '')}</textarea>
        <button id="saveNotesBtn" class="primary-btn" type="button" style="margin-top:10px">Salvar anotações</button>
      </article>
    `;

    bindSheetControls();
    renderInventory();
  }

  function renderMeter(label, current, max, type) {
    const pct = max > 0 ? Math.max(0, Math.min(100, (current / max) * 100)) : 0;
    return `
      <div class="meter-control">
        <div class="meter-top"><strong>${label}: <span id="${type}-value">${current}</span>/${max}</strong>
          <div class="meter-buttons">
            <button type="button" data-meter="${type}" data-delta="-1">−</button>
            <button type="button" data-meter="${type}" data-delta="1">+</button>
          </div>
        </div>
        <div class="meter ${type === 'energy' ? 'energy' : ''}"><span id="${type}-bar" style="width:${pct}%"></span></div>
      </div>`;
  }

  function bindSheetControls() {
    document.querySelectorAll('[data-meter]').forEach(btn => {
      btn.addEventListener('click', () => adjustMeter(btn.dataset.meter, Number(btn.dataset.delta)));
    });
    $('addCreditsBtn').addEventListener('click', () => adjustCredits(Math.abs(Number($('creditsDelta').value || 0))));
    $('removeCreditsBtn').addEventListener('click', () => adjustCredits(-Math.abs(Number($('creditsDelta').value || 0))));
    $('customItemAddBtn').addEventListener('click', () => {
      const name = $('customItemName').value.trim();
      const qty = Math.max(1, Number($('customItemQty').value || 1));
      if (!name) return toast('Digite o nome do item.');
      const c = getActiveCharacter();
      addInventoryItem(c.inventory, name, qty, 'Adicionado manualmente');
      c.updatedAt = new Date().toISOString();
      persistCharacters();
      $('customItemName').value = '';
      $('customItemQty').value = 1;
      renderInventory();
      toast('Item adicionado.');
    });
    $('saveNotesBtn').addEventListener('click', () => {
      const c = getActiveCharacter();
      c.notes = $('playerNotes').value;
      c.updatedAt = new Date().toISOString();
      persistCharacters();
      toast('Anotações salvas.');
    });
  }

  function adjustMeter(type, delta) {
    const c = getActiveCharacter();
    if (!c) return;
    const currentKey = type === 'life' ? 'currentLife' : 'currentEnergy';
    const maxKey = type === 'life' ? 'maxLife' : 'maxEnergy';
    c[currentKey] = clamp(c[currentKey] + delta, 0, c[maxKey]);
    c.updatedAt = new Date().toISOString();
    persistCharacters();
    $(`${type}-value`).textContent = c[currentKey];
    $(`${type}-bar`).style.width = `${(c[currentKey] / c[maxKey]) * 100}%`;
  }

  function adjustCredits(delta) {
    const c = getActiveCharacter();
    if (!c) return;
    const next = c.credits + delta;
    if (next < 0) return toast('O saldo não pode ficar negativo.');
    c.credits = next;
    c.updatedAt = new Date().toISOString();
    persistCharacters();
    $('sheetCredits').textContent = formatCredits(c.credits);
    $('shopCredits').textContent = `${formatCredits(c.credits)} Créditos`;
  }

  function renderInventory() {
    const c = getActiveCharacter();
    const list = $('inventoryList');
    if (!c || !list) return;
    c.inventory = normalizeInventory(c.inventory);
    if (!c.inventory.length) {
      list.innerHTML = '<div class="empty-state"><p>Inventário vazio.</p></div>';
      return;
    }
    list.innerHTML = c.inventory.map((item, index) => `
      <div class="inventory-item">
        <div><h5>${escapeHtml(item.name)}</h5><p>${escapeHtml(item.note || 'Item')}</p></div>
        <div class="qty-control">
          <button type="button" data-inv-index="${index}" data-delta="-1">−</button>
          <strong>${item.qty}</strong>
          <button type="button" data-inv-index="${index}" data-delta="1">+</button>
        </div>
      </div>
    `).join('');
    list.querySelectorAll('[data-inv-index]').forEach(btn => {
      btn.addEventListener('click', () => {
        const index = Number(btn.dataset.invIndex);
        c.inventory[index].qty += Number(btn.dataset.delta);
        if (c.inventory[index].qty <= 0) c.inventory.splice(index, 1);
        c.updatedAt = new Date().toISOString();
        persistCharacters();
        renderInventory();
      });
    });
  }

  function renderShopCategories() {
    const categories = ['Todos', ...new Set(SHOP.map(i => i.category))];
    $('shopCategory').innerHTML = categories.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
  }

  function renderShop() {
    const active = getActiveCharacter();
    $('shopCredits').textContent = active ? `${formatCredits(active.credits)} Créditos` : 'Selecione uma ficha';
    const search = ($('shopSearch')?.value || '').trim().toLowerCase();
    const category = $('shopCategory')?.value || 'Todos';
    const items = SHOP.filter(item => {
      const matchesSearch = !search || `${item.name} ${item.category} ${item.detail} ${item.extra}`.toLowerCase().includes(search);
      const matchesCategory = category === 'Todos' || item.category === category;
      return matchesSearch && matchesCategory;
    });

    $('shopList').innerHTML = items.map(item => `
      <article class="shop-item">
        <div>
          <span class="eyebrow">${escapeHtml(item.category)}</span>
          <h5>${escapeHtml(item.name)}</h5>
          <div class="shop-meta">
            ${item.detail ? `<span>${escapeHtml(item.detail)}</span>` : ''}
            ${item.extra ? `<span>${escapeHtml(item.extra)}</span>` : ''}
          </div>
        </div>
        <div class="shop-actions">
          <div class="shop-price">${item.price === 0 ? 'Grátis' : `${formatCredits(item.price)} Créditos`}</div>
          <button class="primary-btn" data-buy-id="${item.id}" type="button" ${!active ? 'disabled' : ''}>Comprar</button>
        </div>
      </article>
    `).join('');

    document.querySelectorAll('[data-buy-id]').forEach(btn => {
      btn.addEventListener('click', () => buyShopItem(btn.dataset.buyId));
    });
  }

  function buyShopItem(id) {
    const c = getActiveCharacter();
    if (!c) return toast('Selecione uma ficha primeiro.');
    const item = SHOP.find(i => i.id === id);
    if (!item) return;
    if (c.credits < item.price) return toast('Créditos insuficientes.');

    let qty = 1;
    const match = item.name.match(/\((\d+)\)$/);
    let inventoryName = item.name;
    if (match && item.category === 'Munições') {
      qty = Number(match[1]);
      inventoryName = item.name.replace(/\s*\(\d+\)$/, '');
    }

    c.credits -= item.price;
    addInventoryItem(c.inventory, inventoryName, qty, `Compra • ${item.category}`);
    c.updatedAt = new Date().toISOString();
    persistCharacters();
    renderShop();
    toast(`${inventoryName} adicionado ao inventário.`);
  }

  function renderRules() {
    $('rulesContent').innerHTML = `
      <article class="rule-card"><h4>Testes</h4><p>O sistema usa 1d100. O Mestre realiza as rolagens.</p><ul><li>Sucesso: resultado igual ou menor que o atributo.</li><li>Falha: resultado maior que o atributo.</li><li>Não existem críticos, bônus, penalidades, vantagem ou desvantagem.</li></ul></article>
      <article class="rule-card"><h4>Atributos</h4><ul><li><strong>Corpo:</strong> força, resistência e combate corpo a corpo.</li><li><strong>Agilidade:</strong> reflexos, esquiva e armas à distância.</li><li><strong>Intelecto:</strong> investigação, medicina e análise.</li><li><strong>Presença:</strong> persuasão, intimidação e interação social.</li><li><strong>Espírito:</strong> resistência sobrenatural e rituais.</li></ul></article>
      <article class="rule-card"><h4>Criação</h4><ul><li>Distribua 200% entre os cinco atributos.</li><li>Mínimo inicial: 20%.</li><li>Máximo inicial: 60%.</li><li>Vida = 10 + Corpo ÷ 5.</li><li>Energia = 5 + Espírito ÷ 5.</li></ul></article>
      <article class="rule-card"><h4>Combate</h4><ul><li>Corpo a corpo usa Corpo.</li><li>Armas de fogo, arco, balestra e estilingue usam Agilidade.</li><li>Rituais usam Espírito.</li><li>As armas causam dano fixo.</li></ul></article>
      <article class="rule-card"><h4>Reações</h4><ul><li><strong>Esquiva:</strong> teste de Agilidade.</li><li><strong>Bloqueio:</strong> teste de Corpo e reduz o dano pela metade quando bem-sucedido.</li></ul></article>
      <article class="rule-card"><h4>Progressão</h4><ul><li>Existem cinco níveis.</li><li>Cada novo nível concede +10% para distribuir.</li><li>O limite absoluto de qualquer atributo é 90%.</li></ul></article>
      <article class="rule-card"><h4>Equipamentos iniciais</h4><p>Todo personagem começa com faca, celular, documentos, roupas, mochila e um objeto pessoal. Também recebe 1.000 Créditos para compras.</p></article>
    `;
  }

  function renderRituals() {
    $('ritualList').innerHTML = Object.entries(RITUALS).map(([level, list]) => `
      <article class="ritual-level"><h4>Nível ${level}</h4><ul>${list.map(name => `<li>${escapeHtml(name)}</li>`).join('')}</ul></article>
    `).join('');
  }

  function exportBackup() {
    const payload = { app: 'Asylum Player', version: 1, exportedAt: new Date().toISOString(), characters };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `asylum-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 500);
  }

  function importBackup(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const payload = JSON.parse(String(reader.result));
        if (!Array.isArray(payload.characters)) throw new Error('Formato inválido');
        const imported = payload.characters.map(validateCharacter).filter(Boolean);
        if (!imported.length) throw new Error('Nenhuma ficha válida');
        confirmAction('Importar backup', `Isso substituirá as ${characters.length} ficha(s) atuais por ${imported.length} ficha(s) do arquivo.`, () => {
          characters = imported;
          activeId = imported[0]?.id || '';
          if (activeId) localStorage.setItem(ACTIVE_KEY, activeId);
          persistCharacters();
          renderCharacterList();
          showView('home');
          toast('Backup importado.');
        });
      } catch (err) {
        toast('Não foi possível importar este arquivo.');
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  }

  function validateCharacter(c) {
    if (!c || typeof c !== 'object' || !c.name || !c.attributes) return null;
    return {
      ...c,
      id: c.id || cryptoRandomId(),
      attributes: { ...ARCHETYPES.personalizado, ...c.attributes },
      inventory: normalizeInventory(c.inventory || []),
      credits: Math.max(0, Number(c.credits || 0)),
      maxLife: Number(c.maxLife || calcLife(c.attributes.corpo || 40)),
      currentLife: Number(c.currentLife ?? c.maxLife ?? calcLife(c.attributes.corpo || 40)),
      maxEnergy: Number(c.maxEnergy || calcEnergy(c.attributes.espirito || 40)),
      currentEnergy: Number(c.currentEnergy ?? c.maxEnergy ?? calcEnergy(c.attributes.espirito || 40)),
      updatedAt: c.updatedAt || new Date().toISOString()
    };
  }

  function loadCharacters() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(raw) ? raw.map(validateCharacter).filter(Boolean) : [];
    } catch {
      return [];
    }
  }

  function persistCharacters() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(characters));
  }

  function getActiveCharacter() {
    return characters.find(c => c.id === activeId) || null;
  }

  function normalizeInventory(items) {
    const map = new Map();
    (items || []).forEach(item => {
      if (!item?.name) return;
      const key = item.name.trim().toLowerCase();
      const qty = Math.max(0, Number(item.qty || 0));
      if (!qty) return;
      if (map.has(key)) {
        map.get(key).qty += qty;
      } else {
        map.set(key, { name: item.name.trim(), qty, note: item.note || '' });
      }
    });
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
  }

  function addInventoryItem(inventory, name, qty = 1, note = '') {
    const key = name.trim().toLowerCase();
    const existing = inventory.find(i => i.name.trim().toLowerCase() === key);
    if (existing) existing.qty += qty;
    else inventory.push({ name: name.trim(), qty, note });
  }

  function confirmAction(title, text, onConfirm) {
    const dialog = $('confirmDialog');
    $('dialogTitle').textContent = title;
    $('dialogText').textContent = text;
    dialog.returnValue = '';
    dialog.showModal();
    const handler = () => {
      dialog.removeEventListener('close', handler);
      if (dialog.returnValue === 'confirm') onConfirm();
    };
    dialog.addEventListener('close', handler);
  }

  function toast(message) {
    const el = $('toast');
    el.textContent = message;
    el.classList.remove('hidden');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => el.classList.add('hidden'), 2200);
  }

  function calcLife(corpo) { return 10 + Math.floor(Number(corpo) / 5); }
  function calcEnergy(espirito) { return 5 + Math.floor(Number(espirito) / 5); }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value))); }
  function roundTo5(value) { return Math.round(Number(value) / 5) * 5; }
  function formatCredits(value) { return new Intl.NumberFormat('pt-BR').format(Number(value || 0)); }
  function cryptoRandomId() {
    if (window.crypto?.randomUUID) return window.crypto.randomUUID();
    return `char-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator && location.protocol !== 'file:') {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }
})();
