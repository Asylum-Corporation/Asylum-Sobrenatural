# Geração do APK

Abra esta pasta no Android Studio e execute:

Build > Build APK(s)

O APK de teste será criado normalmente em:

app/build/outputs/apk/debug/app-debug.apk

Este projeto não usa bibliotecas externas de interface. O conteúdo do aplicativo fica em `app/src/main/assets`.
