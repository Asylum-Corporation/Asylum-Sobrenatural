# Asylum — Aplicativo do Jogador

Aplicativo móvel para jogadores de **Asylum — Marcas do Sobrenatural**.

## Funcionalidades

- criação automática de ficha por arquétipo;
- distribuição personalizada de 200% entre os cinco atributos;
- cálculo automático de Vida e Energia;
- kits iniciais com desconto automático de Créditos;
- inclusão automática dos equipamentos gratuitos;
- salvamento local de múltiplas fichas;
- controle de Vida, Energia e Créditos;
- inventário com botões de adicionar e remover;
- loja com armas, munições, equipamentos e validação de saldo;
- regras rápidas para jogadores;
- lista de rituais por nível;
- exportação e importação de backup em JSON;
- funcionamento offline como PWA;
- versão Android WebView pronta para abrir no Android Studio.

## Versão web instalável

Abra `index.html` por um servidor local ou hospede a pasta em qualquer servidor HTTPS. Em um navegador Android compatível, use a opção **Adicionar à tela inicial**.

## Projeto Android

A pasta `android-project` contém o projeto Android nativo com WebView e todos os arquivos incorporados em `app/src/main/assets`.

Para gerar o APK no Android Studio:

1. Abra a pasta `android-project`.
2. Aguarde a sincronização do Gradle.
3. Use **Build > Build APK(s)**.

O projeto usa:

- package: `com.asylum.player`
- minSdk: 24
- targetSdk: 35
- versão: 1.0.0

## Privacidade

Os dados ficam salvos apenas no aparelho do jogador, usando armazenamento local. O aplicativo não envia informações para servidores externos.
